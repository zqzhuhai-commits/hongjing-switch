@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-CHS.ps1"
pause
