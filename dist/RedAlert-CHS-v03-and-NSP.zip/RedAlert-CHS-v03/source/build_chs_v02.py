from pathlib import Path
import struct,re,hashlib,json,shutil,bisect
from mixlib import Mix,namehash
OUT=Path('RedAlert-CHS-v02');(OUT/'patch').mkdir(parents=True,exist_ok=True)
def contents(m):return {k:m.b[m.start+o:m.start+o+n] for k,(o,n) in m.entries.items()}
def signed(k):return k if k<0x80000000 else k-0x100000000
def pack(items):
 tab=bytearray();body=bytearray()
 for k in sorted(items,key=signed):
  tab.extend(struct.pack('<III',k,len(body),len(items[k])));body.extend(items[k])
 return b'\0'*4+struct.pack('<HI',len(items),len(body))+tab+body

def split_strings(b):
 n=struct.unpack_from('<H',b)[0]//2;out=[]
 for i in range(n):
  o=struct.unpack_from('<H',b,i*2)[0];assert n*2<=o<len(b)
  e=b.find(b'\0',o);assert e>=o;out.append(b[o:e])
 return out
source=Path('upload/EXPAND2.MIX').read_bytes();original=Mix(source);before=contents(original)
old=split_strings(original.get('CONQUER.ENG'))
lang=Mix(Path('cn-inspect/germanuncensoredlanguagepack.MIX').read_bytes())
zh=split_strings(lang.get('CONQUER.ENG'))
eng=split_strings(Mix(Path('cn-inspect/EXPAND3.MIX').read_bytes()).get('CONQUER.ENG'))
assert len(old)<=len(zh)==len(eng)
result=[];fallback=[]
fmt=re.compile(rb'%(?:[-+#0 ]*)(?:\d+|\*)?(?:\.(?:\d+|\*))?(?:hh|ll|h|l|L|z)?[diuoxXfFeEgGcsnp%]')
for i,e in enumerate(old):
 z=zh[i] if e==eng[i] else e
 if z==e and e!=eng[i]:fallback.append(i)
 if fmt.findall(e)!=fmt.findall(z):z=e;fallback.append(i)
 result.append(z)
result[362]=zh[119]
for i,(e,z) in enumerate(zip(old,result)):assert fmt.findall(e)==fmt.findall(z),(i,e,z)
off=len(result)*2;offsets=[];body=bytearray()
for s in result:offsets.append(off);body.extend(s+b'\0');off+=len(s)+1
assert off<65536
text=struct.pack('<'+'H'*len(result),*offsets)+body
fonts=['12METFNT.FNT','HELP.FNT','GRAD6FNT.FNT','SCOREFNT.FNT','VCR.FNT']
items=dict(before);items[namehash('CONQUER.ENG')]=bytes(text)
for n in fonts:items[namehash(n)]=lang.get(n)
patched=pack(items);(OUT/'patch/EXPAND2.MIX').write_bytes(patched)
check=Mix(patched);after=contents(check)
assert len(old)==len(split_strings(check.get('CONQUER.ENG')))
assert split_strings(check.get('CONQUER.ENG'))==result
assert all(before[k]==after[k] for k in before if k!=namehash('CONQUER.ENG'))
assert len(before)==32 and len(after)==37
# Test the packed index using the engine's signed-hash binary search order.
ids=[struct.unpack_from('<I',patched,10+i*12)[0] for i in range(len(after))]
keys=list(map(signed,ids));assert keys==sorted(keys)
for n in ['CONQUER.ENG']+fonts:
 k=namehash(n);i=bisect.bisect_left(keys,signed(k));assert ids[i]==k
 off,size=struct.unpack_from('<II',patched,10+i*12+4)
 assert patched[check.start+off:check.start+off+size]==check.get(n)
hires=Mix(Path('upload/HIRES1.MIX').read_bytes());red=Mix(Path('upload/REDALERT.MIX').read_bytes())
local=Mix(red.get('LOCAL.MIX'));high=Mix(red.get('HIRES.MIX'))
def lookup(boot,name):
 for container in [boot,hires,red,local,high]:
  if container.has(name):return container.get(name)
 raise KeyError(name)
assert split_strings(lookup(original,'CONQUER.ENG'))[17]==b'Start New Game'
assert split_strings(lookup(check,'CONQUER.ENG'))[17]==zh[17]
for n in fonts:assert lookup(check,n)==lang.get(n)
preview_old=split_strings(local.get('CONQUER.ENG'))
for i in [362,17,35,154,18,46,122,123,126,140]:assert result[i]==preview_old[i]
shutil.copyfile('RedAlert-CHS-Test/resource-preview.png',OUT/'resource-preview.png')
manifest={
 'version':'0.2','file_name':'EXPAND2.MIX',
 'original_sha256':hashlib.sha256(source).hexdigest(),
 'patched_sha256':hashlib.sha256(patched).hexdigest(),
 'original_size':len(source),'patched_size':len(patched),
 'original_entries':len(before),'patched_entries':len(after),
 'text_slots':len(old),'changed_slots':sum(a!=b for a,b in zip(old,result)),
 'replaced':['CONQUER.ENG'],'added':fonts,
 'original_non_text_entries_preserved':len(before)-1,
 'original_text_fallbacks':fallback,
 'load_order_test':{'before_menu_17':'Start New Game','after_menu_17_hex':result[17].hex(),'lookup_source':'EXPAND2.MIX','fonts_source':'EXPAND2.MIX'},
 'nro_changed':False,'hires1_changed':False,'redalert_changed':False,
 'runtime_tested_on_switch':False
}
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps(manifest,ensure_ascii=False,indent=2))
