param([string]$TargetFolder)
$ErrorActionPreference = 'Stop'
$jobs = @()
try {
    $root = $PSScriptRoot
    $manifest = Get-Content -LiteralPath (Join-Path $root 'manifest.json') -Raw | ConvertFrom-Json
    if (-not $TargetFolder) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Choose your microSD root or switch/redalert folder'
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
        $TargetFolder = $dialog.SelectedPath
    }
    if (-not (Test-Path -LiteralPath (Join-Path $TargetFolder 'EXPAND2.MIX'))) {
        $TargetFolder = Join-Path $TargetFolder 'switch\redalert'
    }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
    # Validate both files before making any changes.
    foreach ($name in @('EXPAND2.MIX', 'RedAlert.nro')) {
        $spec = $manifest.files.$name
        $source = Join-Path $root ('patch\' + $name)
        $target = Join-Path $TargetFolder $name
        if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw ('Missing: ' + $target) }
        if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $spec.sha256) { throw ('Patch integrity error: ' + $name) }
        $current = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($current -eq $spec.sha256) { continue }
        if ($spec.accepted_before -notcontains $current) { throw ('Untested base file: ' + $name + '. No files were changed.') }
        $jobs += [PSCustomObject]@{Source=$source; Target=$target; Before=$current; After=$spec.sha256; Backup=($target+'.before-v03-'+$stamp+'.bak'); Staged=($target+'.v03-new'); Changed=$false}
    }
    foreach ($job in $jobs) {
        if (Test-Path -LiteralPath $job.Staged) { throw ('Staging file exists: ' + $job.Staged) }
        Copy-Item -LiteralPath $job.Target -Destination $job.Backup
        if ((Get-FileHash -LiteralPath $job.Backup -Algorithm SHA256).Hash.ToLowerInvariant() -ne $job.Before) { throw 'Backup verification failed.' }
        Copy-Item -LiteralPath $job.Source -Destination $job.Staged
        if ((Get-FileHash -LiteralPath $job.Staged -Algorithm SHA256).Hash.ToLowerInvariant() -ne $job.After) { throw 'Staged file verification failed.' }
    }
    foreach ($job in $jobs) {
        $job.Changed = $true
        Move-Item -LiteralPath $job.Staged -Destination $job.Target -Force
        if ((Get-FileHash -LiteralPath $job.Target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $job.After) { throw 'Installed file verification failed.' }
    }
    Write-Host 'Chinese patch v0.3 installed. Fully close and restart the game. Keep your existing NSP.' -ForegroundColor Green
} catch {
    $message = $_.Exception.Message
    foreach ($job in $jobs) {
        if ($job.Changed) {
            try { Copy-Item -LiteralPath $job.Backup -Destination $job.Target -Force }
            catch { Write-Host ('Restore manually from: '+$job.Backup) -ForegroundColor Red }
        }
    }
    Write-Host ('ERROR: '+$message) -ForegroundColor Red
    exit 1
}
