from pathlib import Path
from mixlib import Mix,namehash
from PIL import Image,ImageDraw
import struct
lang=Mix(Path('cn-inspect/germanuncensoredlanguagepack.MIX').read_bytes())
root=Mix(Path('upload/REDALERT.MIX').read_bytes());subs=[Mix(root.get(n)) for n in ['LOCAL.MIX','HIRES.MIX','LORES.MIX']]
main=Mix(Path('cn-inspect/MAIN.MIX').read_bytes());conquer=Mix(main.get('CONQUER.MIX'))
def find(n):
 for m in [root]+subs+[main,conquer]:
  if m.has(n):return m.get(n)
 raise KeyError(n)
pal=find('TEMPERAT.PAL');assert len(pal)==768;pal=[min(255,x*4) for x in pal]
def lcw(b):
 out=bytearray();i=0
 while True:
  c=b[i];i+=1
  if c==128:break
  if not c&128:
   count=(c>>4)+3;off=((c&15)<<8)|b[i];i+=1;start=len(out)-off
   assert off>0
   for j in range(count):out.append(out[start+j])
  elif c<192:
   count=c&63;out.extend(b[i:i+count]);i+=count
  elif c==254:
   count=struct.unpack_from('<H',b,i)[0];v=b[i+2];i+=3;out.extend(bytes([v])*count)
  else:
   if c==255:count=struct.unpack_from('<H',b,i)[0];i+=2
   else:count=(c&63)+3
   start=struct.unpack_from('<H',b,i)[0];i+=2
   for j in range(count):out.append(out[start+j])
 return out

def shape(b):
 count,_,_,w,h=struct.unpack_from('<5H',b);assert count==1 and 0<w<256 and 0<h<256
 flagged=struct.unpack_from('<I',b,14)[0];assert flagged>>24==128
 pixels=lcw(b[flagged&0xffffff:]);assert len(pixels)==w*h,(w,h,len(pixels))
 im=Image.frombytes('P',(w,h),bytes(pixels));im.putpalette(pal);return im.convert('RGB')
if __name__=='__main__':
 names=['POWRICON.SHP','APWRICON.SHP','PROCICON.SHP','WEAPICON.SHP','BARRICON.SHP','TSLAICON.SHP','DOMEICON.SHP','STEKICON.SHP']
 canvas=Image.new('RGB',(720,500),'#161b22');draw=ImageDraw.Draw(canvas)
 draw.text((20,12),'EXTRACTED ASSETS - NOT A SWITCH SCREENSHOT',fill='white')
 draw.text((20,36),'Original icons',fill='#aab5c4');draw.text((380,36),'Supplied Chinese icons',fill='#aab5c4')
 for idx,name in enumerate(names):
  row,col=divmod(idx,4)
  for side,source in enumerate([find(name),lang.get(name)]):
   im=shape(source).resize((128,96),Image.Resampling.NEAREST)
   x=20+side*360+(col%2)*160;y=70+((idx//2)%4)*104
   canvas.paste(im,(x,y))
 canvas.save('cameo-comparison.png')
 print('Sidebar cameo decoding verified for',len(names),'original and localized pairs')
