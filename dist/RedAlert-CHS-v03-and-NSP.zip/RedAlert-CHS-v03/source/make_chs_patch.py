from pathlib import Path
import struct,re,hashlib,json,shutil
from mixlib import Mix,namehash
from PIL import Image,ImageDraw
OUT=Path('RedAlert-CHS-Test');data=OUT/'patch';data.mkdir(parents=True,exist_ok=True)
basebytes=Path('cn-inspect/REDALERT.MIX').read_bytes();root=Mix(basebytes)
def entries(m):return {k:m.b[m.start+o:m.start+o+n] for k,(o,n) in m.entries.items()}
def pack(items):
 keys=sorted(items,key=lambda k:k if k<0x80000000 else k-0x100000000)
 body=bytearray();tab=bytearray()
 for k in keys:tab.extend(struct.pack('<III',k,len(body),len(items[k])));body.extend(items[k])
 return b'\0'*4+struct.pack('<HI',len(keys),len(body))+tab+body
lang=Mix(Path('cn-inspect/germanuncensoredlanguagepack.MIX').read_bytes())
oldtext=Mix(root.get('LOCAL.MIX')).get('CONQUER.ENG');english=Mix(Path('cn-inspect/EXPAND3.MIX').read_bytes()).get('CONQUER.ENG');translated=lang.get('CONQUER.ENG')
def strings(b):
 n=struct.unpack_from('<H',b)[0]//2;r=[]
 for i in range(n):
  o=struct.unpack_from('<H',b,2*i)[0];end=b.find(b'\0',o);assert end>=o;r.append(b[o:end])
 return r
old,eng,zh=map(strings,[oldtext,english,translated]);assert len(eng)==len(zh)==556
result=list(zh);fallback=[]
for i in range(len(old)):
 if old[i]!=eng[i]:result[i]=old[i];fallback.append(i)
# Original engine uses slot 362; the PC patch uses slot 119 for expansion missions.
result[362]=zh[119]
# Remaster-only slot is not a normal text entry in the original game.
result[555]=eng[555]
fmt=re.compile(rb'%(?:[-+#0 ]*)(?:\d+|\*)?(?:\.(?:\d+|\*))?(?:hh|ll|h|l|L|z)?[diuoxXfFeEgGcsnp%]')
for i,(e,z) in enumerate(zip(eng,result)):
 if i in fallback:continue
 if fmt.findall(e)!=fmt.findall(z):
  print('Format fallback',i,repr(e),repr(z));result[i]=e;fallback.append(i)
body=b''.join(s+b'\0' for s in result);offsets=[];o=len(result)*2
for s in result:offsets.append(o);o+=len(s)+1
assert o<65536
newtext=struct.pack('<'+'H'*len(offsets),*offsets)+body
fonts=['12METFNT.FNT','HELP.FNT','GRAD6FNT.FNT','SCOREFNT.FNT','VCR.FNT']
# All font files supplied by the selected language pack; keep unmodified fonts intact.
for n in ['EDITFNT.FNT','8POINT.FNT','3POINT.FNT','6POINT.FNT','LED.FNT']:
 if lang.has(n):fonts.append(n)
resources={n:lang.get(n) for n in fonts}
rootitems=entries(root);changes={}
for sub in ['LOCAL.MIX','HIRES.MIX']:
 before=Mix(root.get(sub));items=entries(before);replaced=[]
 for name,b in resources.items():
  if before.has(name):items[namehash(name)]=b;replaced.append(name)
 if sub=='LOCAL.MIX':items[namehash('CONQUER.ENG')]=newtext;replaced.append('CONQUER.ENG')
 new=pack(items);check=Mix(new)
 for k,content in items.items():
  off,n=check.entries[k];assert check.b[check.start+off:check.start+off+n]==content
 rootitems[namehash(sub)]=new;changes[sub]=replaced
outbytes=pack(rootitems);(data/'REDALERT.MIX').write_bytes(outbytes);newroot=Mix(outbytes)
for k,oldbytes in entries(root).items():
 if k not in [namehash('LOCAL.MIX'),namehash('HIRES.MIX')]:
  off,n=newroot.entries[k];assert outbytes[newroot.start+off:newroot.start+off+n]==oldbytes
for sub in ['LOCAL.MIX','HIRES.MIX']:
 before=entries(Mix(root.get(sub)));after=entries(Mix(newroot.get(sub)));changed={namehash(n) for n in changes[sub]}
 for k,b in before.items():
  if k not in changed:assert after[k]==b
assert strings(Mix(newroot.get('LOCAL.MIX')).get('CONQUER.ENG'))==result
manifest={'original_sha256':hashlib.sha256(basebytes).hexdigest(),'patched_sha256':hashlib.sha256(outbytes).hexdigest(),'original_size':len(basebytes),'patched_size':len(outbytes),'text_entries':len(result),'translated_entries':sum(1 for a,b in zip(eng,result) if a!=b and any(x<32 or x>126 for x in b)),'restored_original_ids':fallback,'changes':changes,'romfs_or_executable_changed':False}
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
# Render supplied glyphs using the same packed-nibble rows and transparent shadow colors as the engine.
def render(font,text,gradient=True):
 ib,ob,wb,db,hb=struct.unpack_from('<5H',font,4);height=font[ib+4];cnt=font[ib+3]+1
 widths=[font[wb+c] if c<cnt else 1 for c in text];im=Image.new('L',(max(sum(widths),1),height));xbase=0
 for c,w in zip(text,widths):
  assert c<cnt,(c,cnt)
  o=struct.unpack_from('<H',font,ob+2*c)[0];yp,lines=font[hb+2*c:hb+2*c+2]
  assert yp+lines<=height and o+((w+1)//2)*lines<=len(font)
  for y in range(lines):
   for x in range(w):
    byte=font[o+y*((w+1)//2)+x//2];v=(byte&15) if x%2==0 else (byte>>4)
    if v==1 or (gradient and v>=4):im.putpixel((xbase+x,yp+y),255)
  xbase+=w
 return im
preview=Image.new('RGB',(720,580),'#161b22');draw=ImageDraw.Draw(preview);draw.text((24,14),'RESOURCE RENDER ONLY - NOT A SWITCH SCREENSHOT',fill='#aab5c4')
rows=[(362,'GRAD6FNT.FNT'),(17,'GRAD6FNT.FNT'),(35,'GRAD6FNT.FNT'),(154,'GRAD6FNT.FNT'),(18,'GRAD6FNT.FNT'),(46,'GRAD6FNT.FNT'),(122,'HELP.FNT'),(123,'HELP.FNT'),(126,'HELP.FNT'),(140,'HELP.FNT')]
for row,(idx,font) in enumerate(rows):
 im=render(resources[font],result[idx],font=='GRAD6FNT.FNT');im=im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST)
 preview.paste((245,208,105),(190,50+row*50),im);draw.text((24,58+row*50),'Text ID '+str(idx),fill='white')
preview.save(OUT/'resource-preview.png')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
